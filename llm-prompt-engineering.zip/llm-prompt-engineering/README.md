# LLM Prompt Engineering

This repository is a curated collection of prompt engineering strategies, prompt libraries, and datasets for fine-tuning and evaluating large language models (LLMs) in real-world use cases.

## Structure

- `prompts/` – Prompt libraries for product management and prompt engineering.
- `templates/` – Prompt templates and evaluation rubrics.
- `notebooks/` – Jupyter notebooks for testing and evaluating prompt output.
- `datasets/` – Training datasets for prompt tuning or supervised instruction.
- `scripts/` – Python scripts to convert or analyze prompts and responses.

## Goals

- Demonstrate prompt engineering capabilities
- Serve as a testing ground for LLM outputs
- Provide reusable tools and templates for prompt design

## Author

Eva Paunova
